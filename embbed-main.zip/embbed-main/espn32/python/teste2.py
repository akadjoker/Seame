import numbers
import time

import gpiod
import gpiodevice
import numpy as np
import spidev
from gpiod.line import Direction, Value